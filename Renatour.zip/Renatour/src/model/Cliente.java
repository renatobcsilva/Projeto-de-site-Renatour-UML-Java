package model;

public class Cliente {

	private int id_Cliente;
	private String nome;
	private String sobrenome;
	private String email;
	private int telefone;
	private String cidade;
	private String estado;
	private int cep;
	private int dataCompra;

	public Cliente(int id_Cliente, String nome, String sobrenome, String email, int telefone, String cidade,
			String estado, int cep) {

		this.id_Cliente = id_Cliente;
		this.nome = nome;
		this.sobrenome = sobrenome;
		this.email = email;
		this.telefone = telefone;
		this.cidade = cidade;
		this.estado = estado;
		this.cep = cep;
		
	}

	public Cliente() {

	}

	public int getId_Cliente() {
		return id_Cliente;
	}

	public void setId_Cliente(int id_Cliente) {
		this.id_Cliente = id_Cliente;
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public String getSobrenome() {
		return sobrenome;
	}

	public void setSobrenome(String sobrenome) {
		this.sobrenome = sobrenome;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public int getTelefone() {
		return telefone;
	}

	public void setTelefone(int telefone) {
		this.telefone = telefone;
	}

	public String getCidade() {
		return cidade;
	}

	public void setCidade(String cidade) {
		this.cidade = cidade;
	}

	public String getEstado() {
		return estado;
	}

	public void setEstado(String estado) {
		this.estado = estado;
	}

	public int getCep() {
		return cep;
	}

	public void setCep(int cep) {
		this.cep = cep;
	}

	public int getdataCompra() {
		return dataCompra;
	}

	public void setdataCompra(int dataCompra) {
		this.dataCompra = dataCompra;
	}

}
