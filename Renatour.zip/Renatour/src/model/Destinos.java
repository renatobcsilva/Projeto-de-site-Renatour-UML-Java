package model;

public class Destinos {

	private int id_Destino;
	private String nome;
	private double preco;

	public Destinos() {
	}

	public Destinos(int id_Destino, String nome, double preco) {
		this.id_Destino = id_Destino;
		this.nome = nome;
		this.preco = preco;

	}

	public int getId_Destino() {
		return id_Destino;
	}

	public void setId_Destino(int id_Destino) {
		this.id_Destino= id_Destino;
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public double getPreco() {
		return preco;
	}

	public void setPreco(double preco) {
		this.preco = preco;
	}

	@Override
	public String toString() {
		return "Livros [id=" + id_Destino + ", nome=" + nome + ", preco=" + preco + "]";
	}

}