package model;
public class ItensCompra {
	
	private int quantidade;
	private double valor;
	
	private Compras compras;
	private Destinos destinos;

	
	public ItensCompra() {
	}

	public ItensCompra(int quantidade, Compras compras, Destinos destinos) {
		
		this.quantidade = quantidade;
		valorItens(destinos.getPreco());
		this.compras = compras;
		this.destinos = destinos;
	}

	
	public int getQuantidade() {
		return quantidade;
	}

	public void setQuantidade(int quantidade) {
		this.quantidade = quantidade;
	}

	public double getValor() {
		return valor;
	}

	public void setValor(double valor) {
		this.valor = valor;
	}

	public Compras getCompras() {
		return compras;
	}

	public void setCompras(Compras compras) {
		this.compras = compras;
	}
	
	public Destinos getDestinos() {
		return destinos;
	}

	public void setDestinos(Destinos Destinos) {
		this.destinos = Destinos;
	}

	 
	@Override
	public String toString() {
		return "Itens_compra [" + ", quantidade=" + quantidade + ", valor" + valor + ", compras=" + compras
				+ "]";
	}
	
	private void valorItens(double preco) {
		this.valor = this.quantidade * preco;
	}
	
}
