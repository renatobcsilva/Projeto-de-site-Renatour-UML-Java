package model;
import java.sql.Date;
import java.util.ArrayList;
import java.util.List;

public class Compras {
	 
	private int id_Compra;
	private int numCC;
	private int cvv;
	private String nomeCC;
	private String validade;
	private Date data;
	private double total;
	
	private Cliente cliente;
	
	private List<ItensCompra> itens = new ArrayList<ItensCompra>();
	
	
	public Compras() {
		
	}
	
	public Compras(int id_Compra, int numCC, int cvv, String nomeCC, String validade, Date data, double total ) {
		this.id_Compra = id_Compra;
		this.numCC = numCC;
		this.cvv = cvv;
		this.nomeCC = nomeCC;
		this.validade = validade;
		this.data = data;
		this.total = total;
	}

	
	

	public int getId_Compra() {
		return id_Compra;
	}

	public void setId_Compra(int id_Compra) {
		this.id_Compra = id_Compra;
	}

	public int getNumCC() {
		return numCC;
	}

	public void setNumCC(int numCC) {
		this.numCC = numCC;
	}

	public int getCvv() {
		return cvv;
	}

	public void setCvv(int cvv) {
		this.cvv = cvv;
	}

	public String getNomeCC() {
		return nomeCC;
	}

	public void setNomeCC(String nomeCC) {
		this.nomeCC = nomeCC;
	}

	public String getValidade() {
		return validade;
	}

	public void setValidade(String validade) {
		this.validade = validade;
	}

	public Date getData() {
		return data;
	}

	public void setData(Date data) {
		this.data = data;
	}

	public double getTotal() {
		return total;
	}

	public void setTotal(double total) {
		this.total = total;
	}

	public Cliente getCliente() {
		return cliente;
	}

	public void setCliente(Cliente cliente) {
		this.cliente = cliente;
	}

	public List<ItensCompra> getItens() {
		return itens;
	}
	
	public void setItens(List<ItensCompra> itens) {
		this.itens = itens;
	}

	@Override
	public String toString() {
		return "Compras [id=" + id_Compra + ", data=" + data + ", total=" + total + "]";
	}
	
	public double valorCompra() {
		for (int i = 0; i < itens.size(); i++) {
			this.total += itens.get(i).getValor();
		}
		return this.total;
	}
}