package controller;

import java.sql.Connection;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import model.Destinos;
import conexao.Conexao;

public class DestinoDAO {
	Connection conn = null;
	PreparedStatement pstm = null;

	public void save(Destinos Destino) {
		String sql = "INSERT INTO Destinos " + "(nome, preco) " + "values(?, ?);";

		try {

			conn = Conexao.createConnectionToMySQL();

			pstm = conn.prepareStatement(sql);

			pstm.setString(1, Destino.getNome());

			pstm.setDouble(2, Destino.getPreco());

			pstm.execute();

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if (pstm != null) {
					pstm.close();
				}
				if (conn != null) {
					conn.close();
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
		}

	}

	public List<Destinos> getDestinos() {
		String sql = "select * from Destinos;";

		List<Destinos> Destinos = new ArrayList<Destinos>();

		ResultSet rset = null;

		try {
			conn = Conexao.createConnectionToMySQL();

			pstm = conn.prepareStatement(sql);

			rset = pstm.executeQuery();

			while (rset.next()) {
				Destinos Destino = new Destinos();

				Destino.setId_Destino(rset.getInt("id_Destino"));

				Destino.setNome(rset.getString("nome"));

				Destino.setPreco(rset.getDouble("preco"));

				Destinos.add(Destino);

			}

		} catch (Exception e) {
			e.printStackTrace();

		} finally {
			try {
				if (rset != null) {
					rset.close();
				}
				if (pstm != null) {
					pstm.close();
				}
				if (conn != null) {
					conn.close();
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
		}

		return Destinos;
	}

	public void update(Destinos Destino1) {
		String sql = "UPDATE destinos SET nome = ?, preco = ? WHERE id_Destino = ?;";

		try {
			conn = Conexao.createConnectionToMySQL();

			pstm = conn.prepareStatement(sql);

			pstm.setString(1, Destino1.getNome());

			pstm.setDouble(2, Destino1.getPreco());

			pstm.setInt(3, Destino1.getId_Destino());

			pstm.execute();

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if (pstm != null) {
					pstm.close();
				}
				if (conn != null) {
					conn.close();
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
	}

	public void deleteById(int id) {
		String sql = "DELETE FROM Destinos WHERE id_Destino = ?";

		try {
			conn = Conexao.createConnectionToMySQL();

			pstm = conn.prepareStatement(sql);

			pstm.setInt(1, id);

			pstm.execute();

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if (pstm != null) {
					pstm.close();
				}
				if (conn != null) {
					conn.close();
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
	}

	public Destinos getDestinoById(int id) {

		String sql = "select * from Destinos WHERE id_Destino = ?;";

		Destinos Destino = new Destinos();

		ResultSet rset = null;

		try {
			conn = Conexao.createConnectionToMySQL();

			pstm = conn.prepareStatement(sql);

			pstm.setInt(1, id);

			rset = pstm.executeQuery();

			rset.next();

			Destino.setId_Destino(rset.getInt("id_Destino"));

			Destino.setNome(rset.getString("nome"));

			Destino.setPreco(rset.getDouble("preco"));

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if (pstm != null) {
					pstm.close();
				}
				if (conn != null) {
					conn.close();
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
		}

		return Destino;
	}
}