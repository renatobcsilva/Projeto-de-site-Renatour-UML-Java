package controller;

import java.sql.Connection;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import model.Cliente;
import conexao.Conexao;

public class ClienteDAO {
	Connection conn = null;
	PreparedStatement pstm = null;

	public void save(Cliente Cliente) {

		String sql = "INSERT INTO cliente " + "(id_Cliente, nome, sobrenome, email, telefone, cidade, estado, cep) "
				+ "values(?, ?, ?, ?, ?, ?, ?, ?);";

		try {

			conn = Conexao.createConnectionToMySQL();

			pstm = conn.prepareStatement(sql);

			pstm.setInt(1, Cliente.getId_Cliente());

			pstm.setString(2, Cliente.getNome());

			pstm.setString(3, Cliente.getSobrenome());

			pstm.setString(4, Cliente.getEmail());

			pstm.setInt(5, Cliente.getTelefone());

			pstm.setString(6, Cliente.getCidade());

			pstm.setString(7, Cliente.getEstado());

			pstm.setInt(8, Cliente.getCep());

			pstm.execute();

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if (pstm != null) {
					pstm.close();
				}
				if (conn != null) {
					conn.close();
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
		}

	}

	public List<Cliente> getCliente() {

		String sql = "select * from cliente;";

		List<Cliente> Cliente = new ArrayList<Cliente>();

		ResultSet rset = null;

		try {
			conn = Conexao.createConnectionToMySQL();

			pstm = conn.prepareStatement(sql);

			rset = pstm.executeQuery();

			while (rset.next()) {
				Cliente cliente = new Cliente();

				cliente.setId_Cliente(rset.getInt("id_Cliente"));

				cliente.setNome(rset.getString("nome"));

				cliente.setSobrenome(rset.getString("sobrenome"));

				cliente.setEmail(rset.getString("email"));

				cliente.setTelefone(rset.getInt("telefone"));

				cliente.setCidade(rset.getString("cidade"));

				cliente.setEstado(rset.getString("estado"));

				cliente.setCep(rset.getInt("cep"));

				Cliente.add(cliente);

			}

		} catch (Exception e) {
			e.printStackTrace();

		} finally {
			try {
				if (rset != null) {
					rset.close();
				}
				if (pstm != null) {
					pstm.close();
				}
				if (conn != null) {
					conn.close();
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
		}

		return Cliente;
	}

	public void update(Cliente Cliente1) {

		String sql = "UPDATE cliente SET nome=?, sobrenome=?, email=?, telefone=?, cidade=?, estado=?, cep=? WHERE id_Cliente = ?;";

		try {
			conn = Conexao.createConnectionToMySQL();

			pstm = conn.prepareStatement(sql);

			pstm.setString(1, Cliente1.getNome());

			pstm.setString(2, Cliente1.getSobrenome());

			pstm.setString(3, Cliente1.getEmail());

			pstm.setInt(4, Cliente1.getTelefone());

			pstm.setString(5, Cliente1.getCidade());

			pstm.setString(6, Cliente1.getEstado());

			pstm.setInt(7, Cliente1.getCep());

			pstm.setInt(8, Cliente1.getId_Cliente());

			pstm.execute();

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if (pstm != null) {
					pstm.close();
				}
				if (conn != null) {
					conn.close();
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
	}

	public void deleteById(int id_Cliente) {

		String sql = "DELETE FROM cliente WHERE id_Cliente = ?";

		try {
			conn = Conexao.createConnectionToMySQL();

			pstm = conn.prepareStatement(sql);

			pstm.setInt(1, id_Cliente);

			pstm.execute();

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if (pstm != null) {
					pstm.close();
				}
				if (conn != null) {
					conn.close();
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
	}

	public Cliente getClienteById(int id_Cliente) {

		String sql = "select * from cliente WHERE id_Cliente = ?;";

		Cliente cliente = new Cliente();

		ResultSet rset = null;

		try {
			conn = Conexao.createConnectionToMySQL();

			pstm = conn.prepareStatement(sql);

			pstm.setInt(1, id_Cliente);

			rset = pstm.executeQuery();

			rset.next();

			cliente.setId_Cliente(rset.getInt("id_Cliente"));

			cliente.setNome(rset.getString("nome"));

			cliente.setSobrenome(rset.getString("sobrenome"));

			cliente.setEmail(rset.getString("email"));

			cliente.setTelefone(rset.getInt("telefone"));

			cliente.setCidade(rset.getString("cidade"));

			cliente.setEstado(rset.getString("estado"));

			cliente.setCep(rset.getInt("cep"));

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if (pstm != null) {
					pstm.close();
				}
				if (conn != null) {
					conn.close();
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
		}

		return cliente;
	}

}