package view;

import java.util.Scanner;
import model.Cliente;
import controller.ClienteDAO;

public class ClientesCRUD {

	public static void main(String[] args) {

		ClienteDAO clienteDAO = new ClienteDAO();
		Scanner s = new Scanner(System.in);
		int opcao = 0;
		int posicao = 0;

		int id_Cliente = 0;
		String nome = "";
		String sobrenome = "";
		String email = "";
		int telefone = 0;
		String cidade = "";
		String estado = "";
		int cep = 0;

		do {
			System.out.println("========== Renatour Sys v3.20 ==========");
			System.out.println("======== Sistema de Clientes ========");
			System.out.println("1 - Cadastrar cliente");
			System.out.println("2 - Consultar cliente");
			System.out.println("3 - Atualizar cliente");
			System.out.println("4 - Deletar cliente");
			System.out.println("5 - Buscar por id");
			System.out.println("0 - Sair");
			System.out.println("=====================================");
			opcao = s.nextInt();
			s.nextLine();

			switch (opcao) {
			case 1:
				// CREATE
				System.out.println("Digite primeiro nome do cliente: ");
				nome = s.nextLine();
				System.out.println("Digite sobrenome do cliente: ");
				sobrenome = s.nextLine();
				System.out.println("Digite email do cliente: ");
				email = s.nextLine();
				System.out.println("Digite telefone do cliente: 'SEM O DDD - SOMENTE NÚMEROS'");
				telefone = s.nextInt();
				s.nextLine();
				System.out.println("Digite cidade do cliente: ");
				cidade = s.nextLine();
				System.out.println("Digite estado do cliente: ");
				estado = s.nextLine();
				System.out.println("Digite CEP do cliente: 'SOMENTE NÚMEROS'");
				cep = s.nextInt();

				Cliente c1 = new Cliente(id_Cliente, nome, sobrenome, email, telefone, cidade, estado, cep);

				clienteDAO.save(c1);

				System.out.println("\n***  Cadastrado  ***\n");

				break;
			case 2:
				// READ
				for (Cliente c : clienteDAO.getCliente()) {
					System.out.println("Id: " + c.getId_Cliente() + " - Nome: " + c.getNome() + " - Sobrenome: "
							+ c.getSobrenome() + "\n" + " - Email: " + c.getEmail() + " - Telefone: " + c.getTelefone()
							+ "\n" + " - Cidade: " + c.getCidade() + " - Estado: " + c.getEstado() + "\n" + " - CEP: "
							+ c.getCep());
				}

				System.out.println("\n*** Consultado ***\n");
				break;
			case 3:
				// UPDATE
				System.out.println("Digite o id do cliente: ");
				posicao = s.nextInt();
				s.nextLine();
				System.out.println("Digite novo primeiro nome do cliente: ");
				nome = s.nextLine();
				System.out.println("Digite novo sobrenome do cliente: ");
				sobrenome = s.nextLine();
				System.out.println("Digite novo email do cliente: ");
				email = s.nextLine();
				System.out.println("Digite novo telefone do cliente: 'SEM O DDD - SOMENTE NÚMEROS'");
				telefone = s.nextInt();
				s.nextLine();
				System.out.println("Digite cidade do cliente: ");
				cidade = s.nextLine();
				System.out.println("Digite estado do cliente: ");
				estado = s.nextLine();
				System.out.println("Digite CEP do cliente: 'SOMENTE NÚMEROS'");
				cep = s.nextInt();
				s.nextLine();

				Cliente c2 = new Cliente(posicao, nome, sobrenome, email, telefone, cidade, estado, cep);

				clienteDAO.update(c2);

				System.out.println("\n***  Atualizado!  ***\n");
				break;
			case 4:
				// DELETE
				System.out.println("Digite o id do cliente: ");
				posicao = s.nextInt();

				clienteDAO.deleteById(posicao);

				System.out.println("\n***  Deletado! ***\n");

				break;
			case 5:
				// BUSCAR POR ID
				System.out.println("Digite id do cliente: ");
				posicao = s.nextInt();

				Cliente c3 = clienteDAO.getClienteById(posicao);

				System.out.println("Id: " + c3.getId_Cliente() + " - Nome: " + c3.getNome() + " - Sobrenome: "
						+ c3.getSobrenome() + "\n" + " - Email: " + c3.getEmail() + " - Telefone: " + c3.getTelefone()
						+ "\n" + " - Cidade: " + c3.getCidade() + " - Estado: " + c3.getEstado() + "\n" + "CEP: "
						+ c3.getCep());

				break;
			default:
				System.out.println(opcao != 0 ? "Opção invalida, digite novamente." : "");
				break;
			}

		} while (opcao != 0);

		System.out.println("Sistema finalizado!");
		s.close();
	}

}