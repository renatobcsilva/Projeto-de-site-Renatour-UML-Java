package view;

import java.util.Arrays;

import model.Cliente;
import model.Compras;
import model.Destinos;
import model.ItensCompra;

public class Teste {

	public static void main(String[] args) {
		
		Cliente cli1= new Cliente (1, "Renato", "Silva", "renatobcsilva@gmail.com", 969933948, "Rio de Janeiro", "RJ", 22770233);
		Cliente cli2= new Cliente (2, "Joana", "Tavares", "joana@gmail.com", 992688532, "Rio de Janeiro", "RJ", 22745271);

		Compras c1 = new Compras(5, cli1 , "1234123412341234", 123, "Renato Silva", "02/03/2030", "05/04/2022");
		Compras c2 = new Compras(2, cli2,  "1111222233334444", 123, "Joana Tavares", "01/09/2030", "03/10/2021");
		
		Destinos d1= new Destinos(1, "Queenstown", 5300);
		Destinos d2= new Destinos(2, "Gold Coast", 5500);
		
		ItensCompra i1 = new ItensCompra(3, c1, d1);
		ItensCompra i2 = new ItensCompra(1, c2, d2);

		
		System.out.println("\n\nUsuario: " + c1.getCliente().getNome());
		System.out.println("\n\nUsuario: " + c2.getCliente().getNome());
		
		c1.getItens().addAll(Arrays.asList(i1));
		c2.getItens().addAll(Arrays.asList(i2));
		
		for (ItensCompra i : c1.getItens()) {
			System.out.println("Destino(s): "+ i.getDestinos().getNome() 
					+" quantidade: "+ i.getQuantidade() 
					+" valor: " + i.getValor());
		}
		
		for (ItensCompra i : c2.getItens()) {
			System.out.println("Destino(s): "+ i.getDestinos().getNome() 
					+" quantidade: "+ i.getQuantidade() 
					+" valor: " + i.getValor());
		}
		
		System.out.println(" \nValor compra: " + c1.valorCompra());
		System.out.println(" \nValor compra: " + c2.valorCompra());
	}

}
