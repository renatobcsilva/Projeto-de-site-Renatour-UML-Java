package view;

import java.util.Scanner;
import controller.DestinoDAO;
import model.Destinos;

public class DestinosCRUD {

	public static void main(String[] args) {
        
		// Lista de destinos preestabelecido na Renatour:
        // Destinos perth= new Destinos(1, "Perth", 4500);
        // Destinos goldCoast= new Destinos(2, "Gold Coast", 5500);
        // Destinos auckland= new Destinos(3, "Auckland", 4300);
        // Destinos queenstown= new Destinos(4, "Queenstown", 5300);
		
		DestinoDAO destinoDAO = new DestinoDAO();
		Scanner s = new Scanner(System.in);
		int opcao = 0;
		int posicao = 0;

		int id_Destino = 0;
		String nome = "";
		double preco = 0;

		do {
			System.out.println("========== Renatour Sys v20 ==========");
			System.out.println("======== Sistema de Destinos ========");
			System.out.println("1 - Cadastrar destino");
			System.out.println("2 - Consultar destino");
			System.out.println("3 - Atualizar destino");
			System.out.println("4 - Deletar destino");
			System.out.println("5 - Buscar por id");
			System.out.println("0 - Sair");
			System.out.println("=====================================");
			opcao = s.nextInt();
			s.nextLine();

			switch (opcao) {
			case 1:
				// CREATE
				System.out.println("Digite nome do destino: ");
				nome = s.nextLine();
				System.out.println("Digite preco do destino: ");
				preco = s.nextDouble();
				s.nextLine();

				Destinos d1 = new Destinos(id_Destino, nome, preco);

				destinoDAO.save(d1);

				System.out.println("\n***  Cadastrado  ***\n");

				break;
			case 2:
				// READ
				for (Destinos d : destinoDAO.getDestinos()) {
					System.out.println("Id: " + d.getId_Destino() + " - Nome: " + d.getNome() + " - Preço: " + d.getPreco());
				}

				System.out.println("\n*** Consultado ***\n");
				break;
			case 3:
				// UPDATE
				System.out.println("Digite id do destino: ");
				posicao = s.nextInt();
				s.nextLine();
				System.out.println("Digite novo nome do destino: ");
				nome = s.nextLine();
				System.out.println("Digite novo preço do destino: ");
				preco = s.nextDouble();
				s.nextLine();

				Destinos d2 = new Destinos(posicao, nome, preco);

				destinoDAO.update(d2);

				System.out.println("\n***  Atualizado!  ***\n");
				break;
			case 4:
				// DELETE
				System.out.println("Digite id do destino: ");
				posicao = s.nextInt();

				destinoDAO.deleteById(posicao);
				
				System.out.println("\n***  Deletado! ***\n");

				break;
			case 5:
				// BUSCAR POR ID
				System.out.println("Digite id do destino: ");
				posicao = s.nextInt();

				Destinos d3 = destinoDAO.getDestinoById(posicao);

				System.out.println("Id: " + d3.getId_Destino() + " - Nome: " + d3.getNome() + " - Preço: " + d3.getPreco());

				break;
			default:
				System.out.println(opcao != 0 ? "Opção invalida, digite novamente." : "");
				break;
			}

		} while (opcao != 0);

		System.out.println("Sistema finalizado!");
		s.close();
	}

}